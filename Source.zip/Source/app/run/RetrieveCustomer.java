/**
 * @(#)RetrieveCustomer.java
 *
 *
 * @author 
 * @version 1.00 2012/6/19
 */


public class RetrieveCustomer {

    public RetrieveCustomer() {
    }
    
    
}