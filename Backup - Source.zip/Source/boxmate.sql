-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 18, 2012 at 05:30 PM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `boxmate`
--

-- --------------------------------------------------------

--
-- Table structure for table `showings`
--

DROP TABLE IF EXISTS `showings`;
CREATE TABLE IF NOT EXISTS `showings` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `date` varchar(30) NOT NULL,
  `time` varchar(10) NOT NULL,
  `doorsOpen` varchar(10) NOT NULL,
  `theatreID` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `showings`
--

INSERT INTO `showings` (`id`, `date`, `time`, `doorsOpen`, `theatreID`) VALUES
(1, 'June 14, 2012', '19:30', '19:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `shows`
--

DROP TABLE IF EXISTS `shows`;
CREATE TABLE IF NOT EXISTS `shows` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `productionMembers` text NOT NULL,
  `rating` varchar(4) NOT NULL,
  `ranking` int(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `shows`
--

INSERT INTO `shows` (`id`, `name`, `description`, `productionMembers`, `rating`, `ranking`) VALUES
(1, 'The Boyfriend', 'Some crazy awesome description will go here.', 'Director: Mrs. Powell, Lighting: Zachary Seguin', 'PG', 1),
(2, 'Dearly Departed', 'Insert another awesome description here.', 'See The Boyfriend.', '14A', 2),
(3, 'Snow White', 'Insert some really cool awesome description here', '[]', 'PG', 2),
(4, 'High School Musical', 'Insert some really cool awesome description here', '[]', 'PG', 8);

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

DROP TABLE IF EXISTS `tickets`;
CREATE TABLE IF NOT EXISTS `tickets` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `customerID` int(4) NOT NULL,
  `showID` int(4) NOT NULL,
  `showingID` int(4) NOT NULL,
  `row` int(4) NOT NULL,
  `seat` int(4) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tickets`
--

INSERT INTO `tickets` (`ID`, `customerID`, `showID`, `showingID`, `row`, `seat`) VALUES
(2, 5, 1, 0, 1, 1),
(3, 5, 1, 0, 1, 1),
(4, 5, 2, 0, 1, 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
