package app.boxmate;

/**
 * This enumerated type is for show ratings.
 *
 * @author Jonathan Tan
 * @version 1.0.0 (24/05/2012)
 * @since 1.0.0
 */
public enum Rating
{
	/**
	 * Suitable for all ages.
	 *
	 * @since 1.0.0
	 */
    G,

    /**
	 * Parental guidance advised.
	 *
	 * @since 1.0.0
	 */
    PG,

    /**
	 * Persons under 14 years of age must be accompanied by an adult.
	 *
	 * @since 1.0.0
	 */
    A14,

    /**
	 * Persons under 18 years of age must be accompanied by an adult.
	 *
	 * @since 1.0.0
	 */
    A18,

    /**
	 * Admittance restricted to people 18 years of age or older.
	 *
	 * @since 1.0.0
	 */
    R
}//End of enum